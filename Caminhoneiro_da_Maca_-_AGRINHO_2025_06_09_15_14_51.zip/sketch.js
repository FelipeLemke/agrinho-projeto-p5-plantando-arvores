const VELOCIDADE_CAMINHAO = 3.5;
const LARGURA_ESTRADA_TERRA = 600;
const VIDAS_INICIAIS = 5;
const GRAVIDADE = 0.6;
const FORCA_PULO = -11;

let caminhao;
let buracos = [];
let pontuacao;
let vidas;
let viagemNumero;
let jogoAtivo;
let danoAlpha = 0;

function setup() {
  createCanvas(800, 400);
  reiniciarJogo();
}

function draw() {
  if (jogoAtivo) {
    desenharCenario();
    desenharBuracos();
    desenharCaminhao();
    desenharItem();
    
    aplicarFisica();
    controlarCaminhao();
    
    verificarColisaoBuracos();
    verificarEntrega();
    
    desenharInterface();
    desenharFeedbackDano();
  } else {
    desenharTelaFimDeJogo();
  }
}

function reiniciarJogo() {
  pontuacao = 0;
  vidas = VIDAS_INICIAIS;
  viagemNumero = 1;
  jogoAtivo = true;

  caminhao = {
    x: 40, y: 300, largura: 60, altura: 40,
    y_velocidade: 0, estaNoChao: true
  };
  
  gerarNovaPista();
}

function desenharCenario() {
  background(135, 206, 235);
  noStroke();
  fill(139, 69, 19);
  rect(0, 340, LARGURA_ESTRADA_TERRA, height - 340);
  fill(50);
  rect(LARGURA_ESTRADA_TERRA, 340, width - LARGURA_ESTRADA_TERRA, height - 340);
}

function desenharCaminhao() {
  fill(255, 0, 0);
  rect(caminhao.x, caminhao.y, caminhao.largura, caminhao.altura);
  rect(caminhao.x + caminhao.largura, caminhao.y + 10, 20, caminhao.altura - 10);
  fill(0);
  ellipse(caminhao.x + 15, caminhao.y + 45, 20, 20);
  ellipse(caminhao.x + 55, caminhao.y + 45, 20, 20);
}

function desenharItem() {
  fill(255, 0, 0); stroke(0);
  ellipse(caminhao.x + 20, caminhao.y - 10, 30, 30);
}

function desenharBuracos() {
  for (let buraco of buracos) {
    fill(87, 49, 11);
    noStroke();
    rect(buraco.x, 340, buraco.largura, 60);
    fill(66, 37, 8, 150);
    ellipse(buraco.x + buraco.largura / 2, 350, buraco.largura * 0.8, 15);
  }
}

function desenharInterface() {
  fill(0); textSize(22);
  textAlign(LEFT, TOP); text(`Pontuação: ${pontuacao}`, 10, 10);
  textAlign(CENTER, TOP); text(`Viagem Nº: ${viagemNumero}`, width / 2, 10);
  textAlign(RIGHT, TOP); text(`Vidas: ${vidas}`, width - 10, 10);
  
  fill(255); textSize(28);
  textAlign(RIGHT); text("ASFALTO SEGURO", width - 15, 310);
}

function desenharFeedbackDano() {
  if (danoAlpha > 0) {
    fill(255, 0, 0, danoAlpha);
    rect(0, 0, width, height);
    danoAlpha -= 5;
  }
}

function desenharTelaFimDeJogo() {
  fill(0, 0, 0, 150); rect(0, 0, width, height);
  fill(255); textAlign(CENTER, CENTER);
  textSize(50); text("FIM DE VIAGEM", width / 2, height / 2 - 40);
  textSize(32); text(`Pontuação Final: ${pontuacao}`, width / 2, height / 2 + 20);
  textSize(24); text("Pressione ENTER para uma nova jornada", width / 2, height / 2 + 70);
}

function aplicarFisica() {
  caminhao.y += caminhao.y_velocidade;
  caminhao.y_velocidade += GRAVIDADE;
  caminhao.estaNoChao = false;

  if (caminhao.y + caminhao.altura >= 340) {
    caminhao.y = 300;
    caminhao.y_velocidade = 0;
    caminhao.estaNoChao = true;
  }
}

function controlarCaminhao() {
  if (keyIsDown(LEFT_ARROW)) caminhao.x -= VELOCIDADE_CAMINHAO;
  if (keyIsDown(RIGHT_ARROW)) caminhao.x += VELOCIDADE_CAMINHAO;
  caminhao.x = constrain(caminhao.x, 0, width - caminhao.largura - 20);
}

function verificarColisaoBuracos() {
  if (!caminhao.estaNoChao) return;

  for (let buraco of buracos) {
    if (caminhao.x + caminhao.largura > buraco.x && caminhao.x < buraco.x + buraco.largura) {
      vidas--;
      danoAlpha = 100;
      caminhao.x = 40;
      
      if (vidas <= 0) jogoAtivo = false;
      return;
    }
  }
}

function verificarEntrega() {
  if (caminhao.x > LARGURA_ESTRADA_TERRA) {
    pontuacao += 10 * viagemNumero;
    viagemNumero++;
    caminhao.x = 40;
    gerarNovaPista();
  }
}

function gerarNovaPista() {
  buracos = [];
  let numeroDeBuracos = 1 + viagemNumero;
  let espacoMinimoEntreBuracos = caminhao.largura + 60;
  let posicaoAtualX = 200;

  for (let i = 0; i < numeroDeBuracos; i++) {
    if (posicaoAtualX > LARGURA_ESTRADA_TERRA - 100) break;
    
    let larguraBuraco = random(45, 55);
    buracos.push({
      x: posicaoAtualX,
      largura: larguraBuraco
    });
    
    posicaoAtualX += larguraBuraco + espacoMinimoEntreBuracos + random(-20, 20);
  }
}

function keyPressed() {
  if (keyCode === 32 && caminhao.estaNoChao) {
    caminhao.y_velocidade = FORCA_PULO;
  }
  
  if (!jogoAtivo && keyCode === ENTER) {
    reiniciarJogo();
  }
}